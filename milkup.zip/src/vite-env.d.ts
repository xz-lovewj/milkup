/// <reference types="vite/client" />
declare type BrowserWindow = import('electron').BrowserWindow
