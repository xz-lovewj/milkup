"use strict";

// src/preload.ts
var import_electron = require("electron");
import_electron.contextBridge.exposeInMainWorld("electronAPI", {
  openFile: () => import_electron.ipcRenderer.invoke("dialog:openFile"),
  saveFile: (filePath, content) => import_electron.ipcRenderer.invoke("dialog:saveFile", { filePath, content }),
  saveFileAs: (content) => import_electron.ipcRenderer.invoke("dialog:saveFileAs", content),
  on: (channel, listener) => import_electron.ipcRenderer.on(channel, (_event, ...args) => listener(...args)),
  removeListener: (channel, listener) => import_electron.ipcRenderer.removeListener(channel, (_event, ...args) => listener(...args)),
  setTitle: (filePath) => import_electron.ipcRenderer.send("set-title", filePath),
  changeSaveStatus: (isSaved) => import_electron.ipcRenderer.send("change-save-status", isSaved),
  windowControl: (action) => import_electron.ipcRenderer.send("window-control", action),
  closeDiscard: () => import_electron.ipcRenderer.send("close:discard"),
  onOpenFileAtLaunch: (cb) => {
    import_electron.ipcRenderer.once("open-file-at-launch", (_event, payload) => {
      cb(payload);
    });
  },
  openExternal: (url) => import_electron.ipcRenderer.send("shell:openExternal", url),
  getFilePathInClipboard: () => import_electron.ipcRenderer.invoke("clipboard:getFilePath"),
  writeTempImage: (file, tempPath) => import_electron.ipcRenderer.invoke("clipboard:writeTempImage", file, tempPath),
  // 图片路径解析
  resolveImagePath: (markdownFilePath, imagePath) => import_electron.ipcRenderer.invoke("file:resolveImagePath", markdownFilePath, imagePath),
  // 通过路径读取文件（用于拖拽）
  readFileByPath: (filePath) => import_electron.ipcRenderer.invoke("file:readByPath", filePath),
  // 显示文件覆盖确认对话框
  showOverwriteConfirm: (fileName) => import_electron.ipcRenderer.invoke("dialog:showOverwriteConfirm", fileName),
  // 获取拖拽文件的真实路径
  getPathForFile: (file) => {
    try {
      const result = import_electron.webUtils?.getPathForFile(file);
      return result;
    } catch (error) {
      console.error("\u274C preload \u4E2D webUtils \u4E0D\u53EF\u7528:", error);
      return void 0;
    }
  },
  // 字体相关
  getSystemFonts: () => import_electron.ipcRenderer.invoke("get-system-fonts"),
  // 主题编辑器相关
  openThemeEditor: (theme) => import_electron.ipcRenderer.send("open-theme-editor", theme),
  themeEditorWindowControl: (action) => import_electron.ipcRenderer.send("theme-editor-window-control", action),
  saveCustomTheme: (theme) => import_electron.ipcRenderer.send("save-custom-theme", theme),
  platform: process.platform
});
