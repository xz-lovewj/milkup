"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/standardize.js
var require_standardize = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/standardize.js"(exports2, module2) {
    "use strict";
    module2.exports = function(fonts, options) {
      fonts = fonts.map((i) => {
        try {
          i = i.replace(/\\u([\da-f]{4})/ig, (m, s) => String.fromCharCode(parseInt(s, 16)));
        } catch (e) {
          console.log(e);
        }
        if (options && options.disableQuoting) {
          if (i.startsWith('"') && i.endsWith('"')) {
            i = `${i.substr(1, i.length - 2)}`;
          }
        } else if (i.match(/[\s()+]/) && !i.startsWith('"')) {
          i = `"${i}"`;
        }
        return i;
      });
      return fonts;
    };
  }
});

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/darwin/index.js
var require_darwin = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/darwin/index.js"(exports2, module2) {
    "use strict";
    var path3 = require("path");
    var execFile = require("child_process").execFile;
    var exec = require("child_process").exec;
    var util = require("util");
    var pexec = util.promisify(exec);
    var bin = path3.join(__dirname, "fontlist");
    var font_exceptions = ["iconfont"];
    async function getBySystemProfiler() {
      const cmd = `system_profiler SPFontsDataType | grep "Family:" | awk -F: '{print $2}' | sort | uniq`;
      const { stdout } = await pexec(cmd, { maxBuffer: 1024 * 1024 * 10 });
      return stdout.split("\n").map((f) => f.trim()).filter((f) => !!f);
    }
    async function getByExecFile() {
      return new Promise(async (resolve2, reject) => {
        execFile(bin, { maxBuffer: 1024 * 1024 * 10 }, (error, stdout, stderr) => {
          if (error) {
            reject(error);
            return;
          }
          let fonts = [];
          if (stdout) {
            fonts = fonts.concat(stdout.split("\n"));
          }
          if (stderr) {
            console.error(stderr);
          }
          fonts = Array.from(new Set(fonts)).filter((i) => i && !font_exceptions.includes(i));
          resolve2(fonts);
        });
      });
    }
    module2.exports = async () => {
      let fonts = [];
      try {
        fonts = await getByExecFile();
      } catch (e) {
        console.error(e);
      }
      if (fonts.length === 0) {
        try {
          fonts = await getBySystemProfiler();
        } catch (e) {
          console.error(e);
        }
      }
      return fonts;
    };
  }
});

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/win32/getByPowerShell.js
var require_getByPowerShell = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/win32/getByPowerShell.js"(exports2, module2) {
    var exec = require("child_process").exec;
    var parse = (str) => {
      return str.split("\n").map((ln) => ln.trim()).filter((f) => !!f);
    };
    module2.exports = () => new Promise((resolve2, reject) => {
      let cmd = `chcp 65001|powershell -command "chcp 65001|Out-Null;Add-Type -AssemblyName PresentationCore;$families=[Windows.Media.Fonts]::SystemFontFamilies;foreach($family in $families){$name='';if(!$family.FamilyNames.TryGetValue([Windows.Markup.XmlLanguage]::GetLanguage('zh-cn'),[ref]$name)){$name=$family.FamilyNames[[Windows.Markup.XmlLanguage]::GetLanguage('en-us')]}echo $name}"`;
      exec(cmd, { maxBuffer: 1024 * 1024 * 10 }, (err, stdout) => {
        if (err) {
          reject(err);
          return;
        }
        resolve2(parse(stdout));
      });
    });
  }
});

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/win32/getByVBS.js
var require_getByVBS = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/win32/getByVBS.js"(exports2, module2) {
    var os = require("os");
    var fs3 = require("fs");
    var path3 = require("path");
    var execFile = require("child_process").execFile;
    var util = require("util");
    var p_copyFile = util.promisify(fs3.copyFile);
    function tryToGetFonts(s) {
      let a = s.split("\n");
      if (a[0].includes("Microsoft")) {
        a.splice(0, 3);
      }
      a = a.map((i) => {
        i = i.split("	")[0].split(path3.sep);
        i = i[i.length - 1];
        if (!i.match(/^[\w\s]+$/)) {
          i = "";
        }
        i = i.replace(/^\s+|\s+$/g, "").replace(/(Regular|常规)$/i, "").replace(/^\s+|\s+$/g, "");
        return i;
      });
      return a.filter((i) => i);
    }
    async function writeToTmpDir(fn) {
      let tmp_fn = path3.join(os.tmpdir(), "node-font-list-fonts.vbs");
      await p_copyFile(fn, tmp_fn);
      return tmp_fn;
    }
    module2.exports = async () => {
      let fn = path3.join(__dirname, "fonts.vbs");
      const is_in_asar = fn.includes("app.asar");
      if (is_in_asar) {
        fn = await writeToTmpDir(fn);
      }
      return new Promise((resolve2, reject) => {
        let cmd = `cscript`;
        execFile(cmd, [fn], { maxBuffer: 1024 * 1024 * 10 }, (err, stdout, stderr) => {
          let fonts = [];
          if (err) {
            reject(err);
            return;
          }
          if (stdout) {
            fonts = fonts.concat(tryToGetFonts(stdout));
          }
          if (stderr) {
            fonts = fonts.concat(tryToGetFonts(stderr));
          }
          resolve2(fonts);
        });
      });
    };
  }
});

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/win32/index.js
var require_win32 = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/win32/index.js"(exports2, module2) {
    "use strict";
    var os = require("os");
    var getByPowerShell = require_getByPowerShell();
    var getByVBS = require_getByVBS();
    var methods_new = [getByPowerShell, getByVBS];
    var methods_old = [getByVBS, getByPowerShell];
    module2.exports = async () => {
      let fonts = [];
      let os_v = parseInt(os.release());
      let methods = os_v >= 10 ? methods_new : methods_old;
      for (let method of methods) {
        try {
          fonts = await method();
          if (fonts.length > 0) break;
        } catch (e) {
          console.log(e);
        }
      }
      return fonts;
    };
  }
});

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/linux/index.js
var require_linux = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/libs/linux/index.js"(exports2, module2) {
    var exec = require("child_process").exec;
    var util = require("util");
    var pexec = util.promisify(exec);
    async function binaryExists(binary) {
      const { stdout } = await pexec(`whereis ${binary}`);
      return stdout.length > binary.length + 2;
    }
    module2.exports = async () => {
      const fcListBinary = await binaryExists("fc-list") ? "fc-list" : "fc-list2";
      const cmd = fcListBinary + ' -f "%{family[0]}\\n"';
      const { stdout } = await pexec(cmd, { maxBuffer: 1024 * 1024 * 10 });
      const fonts = stdout.split("\n").filter((f) => !!f);
      return Array.from(new Set(fonts));
    };
  }
});

// node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/index.js
var require_font_list = __commonJS({
  "node_modules/.pnpm/font-list@1.5.1/node_modules/font-list/index.js"(exports2) {
    "use strict";
    var standardize = require_standardize();
    var platform = process.platform;
    var getFontsFunc;
    switch (platform) {
      case "darwin":
        getFontsFunc = require_darwin();
        break;
      case "win32":
        getFontsFunc = require_win32();
        break;
      case "linux":
        getFontsFunc = require_linux();
        break;
      default:
        throw new Error(`Error: font-list can not run on ${platform}.`);
    }
    var defaultOptions = {
      disableQuoting: false
    };
    exports2.getFonts = async (options) => {
      options = Object.assign({}, defaultOptions, options);
      let fonts = await getFontsFunc();
      fonts = standardize(fonts, options);
      fonts.sort((a, b) => {
        return a.replace(/^['"]+/, "").toLocaleLowerCase() < b.replace(/^['"]+/, "").toLocaleLowerCase() ? -1 : 1;
      });
      return fonts;
    };
  }
});

// src/main/ipcBridge.ts
function registerIpcOnHandlers(win2) {
  import_electron.ipcMain.on("set-title", (_event, filePath) => {
    const title = filePath ? `milkup - ${import_node_path.default.basename(filePath)}` : "milkup - Untitled";
    win2.setTitle(title);
  });
  import_electron.ipcMain.on("window-control", async (_event, action) => {
    if (!win2)
      return;
    switch (action) {
      case "minimize":
        win2.minimize();
        break;
      case "maximize":
        if (win2.isMaximized())
          win2.unmaximize();
        else win2.maximize();
        break;
      case "close":
        if (process.platform === "darwin") {
          win2.hide();
        } else {
          close(win2);
        }
        break;
    }
  });
  import_electron.ipcMain.on("shell:openExternal", (_event, url) => {
    import_electron.shell.openExternal(url);
  });
  import_electron.ipcMain.on("change-save-status", (_event, isSavedStatus) => {
    isSaved = isSavedStatus;
    win2.webContents.send("save-status-changed", isSaved);
  });
  import_electron.ipcMain.on("menu-save", async (_event, shouldClose) => {
    win2.webContents.send("trigger-save", shouldClose);
  });
  import_electron.ipcMain.on("close:discard", () => {
    isQuitting = true;
    win2.close();
    import_electron.app.quit();
  });
  import_electron.ipcMain.on("open-theme-editor", async () => {
    await createThemeEditorWindow();
  });
  import_electron.ipcMain.on("theme-editor-window-control", async (_event, action) => {
    try {
      console.log("\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3\u63A7\u5236:", action);
      const { createThemeEditorWindow: createThemeEditorWindow2 } = await Promise.resolve().then(() => (init_index(), index_exports));
      const themeEditorWindow2 = await createThemeEditorWindow2();
      if (!themeEditorWindow2) {
        console.log("\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3\u4E0D\u5B58\u5728");
        return;
      }
      if (themeEditorWindow2.isDestroyed()) {
        console.log("\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3\u5DF2\u88AB\u9500\u6BC1");
        return;
      }
      console.log("\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3\u72B6\u6001:", {
        isDestroyed: themeEditorWindow2.isDestroyed(),
        isVisible: themeEditorWindow2.isVisible(),
        isMinimized: themeEditorWindow2.isMinimized(),
        isMaximized: themeEditorWindow2.isMaximized()
      });
      switch (action) {
        case "minimize":
          console.log("\u6700\u5C0F\u5316\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3");
          if (!themeEditorWindow2.isDestroyed()) {
            themeEditorWindow2.minimize();
          }
          break;
        case "maximize":
          console.log("\u6700\u5927\u5316/\u8FD8\u539F\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3");
          if (!themeEditorWindow2.isDestroyed()) {
            if (themeEditorWindow2.isMaximized())
              themeEditorWindow2.unmaximize();
            else
              themeEditorWindow2.maximize();
          }
          break;
        case "close":
          console.log("\u5173\u95ED\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3");
          if (!themeEditorWindow2.isDestroyed()) {
            themeEditorWindow2.close();
          }
          break;
        default:
          console.log("\u672A\u77E5\u7684\u7A97\u53E3\u63A7\u5236\u52A8\u4F5C:", action);
      }
    } catch (error) {
      console.error("\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3\u63A7\u5236\u9519\u8BEF:", error);
    }
  });
  import_electron.ipcMain.on("save-custom-theme", (_event, theme) => {
    win2.webContents.send("custom-theme-saved", theme);
  });
}
function registerIpcHandleHandlers(win2) {
  import_electron.ipcMain.handle("get-system-fonts", async () => {
    console.log("\u83B7\u53D6\u7CFB\u7EDF\u5B57\u4F53\u5217\u8868");
    try {
      const fonts = await (0, import_font_list.getFonts)();
      console.log(fonts);
      return fonts;
    } catch (error) {
      console.error("\u83B7\u53D6\u7CFB\u7EDF\u5B57\u4F53\u5931\u8D25:", error);
      return [];
    }
  });
  import_electron.ipcMain.handle("dialog:openFile", async () => {
    const { canceled, filePaths } = await import_electron.dialog.showOpenDialog(win2, {
      filters: [{ name: "Markdown", extensions: ["md", "markdown"] }],
      properties: ["openFile"]
    });
    if (canceled)
      return null;
    const filePath = filePaths[0];
    const content = fs.readFileSync(filePath, "utf-8");
    return { filePath, content };
  });
  import_electron.ipcMain.handle("dialog:saveFile", async (_event, { filePath, content }) => {
    if (!filePath) {
      const { canceled, filePath: savePath } = await import_electron.dialog.showSaveDialog(win2, {
        filters: [{ name: "Markdown", extensions: ["md", "markdown"] }]
      });
      if (canceled || !savePath)
        return null;
      filePath = savePath;
    }
    fs.writeFileSync(filePath, content, "utf-8");
    return filePath;
  });
  import_electron.ipcMain.handle("dialog:saveFileAs", async (_event, content) => {
    const { canceled, filePath } = await import_electron.dialog.showSaveDialog(win2, {
      filters: [{ name: "Markdown", extensions: ["md", "markdown"] }]
    });
    if (canceled || !filePath)
      return null;
    fs.writeFileSync(filePath, content, "utf-8");
    return { filePath };
  });
  import_electron.ipcMain.handle("clipboard:getFilePath", async () => {
    const platform = process.platform;
    try {
      if (platform === "win32") {
        const buf = import_electron.clipboard.readBuffer("FileNameW");
        const raw = buf.toString("ucs2").replace(/\0/g, "");
        return raw.split("\r\n").filter((s) => s.trim())[0] || null;
      } else if (platform === "darwin") {
        const url = import_electron.clipboard.read("public.file-url");
        return url ? [url.replace("file://", "")] : [];
      } else {
        return [];
      }
    } catch {
      return [];
    }
  });
  import_electron.ipcMain.handle("clipboard:writeTempImage", async (_event, file, tempPath) => {
    const tempDir = import_node_path.default.join(__dirname, tempPath || "/temp");
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir);
    }
    const filePath = import_node_path.default.join(tempDir, `temp-image-${Date.now()}.png`);
    fs.writeFileSync(filePath, file);
    return filePath;
  });
  import_electron.ipcMain.handle("dialog:OpenDialog", async (_event, options) => {
    const response = await import_electron.dialog.showMessageBox(win2, options);
    return response;
  });
  import_electron.ipcMain.handle("dialog:showOverwriteConfirm", async (_event, fileName) => {
    const result = await import_electron.dialog.showMessageBox(win2, {
      type: "question",
      buttons: ["\u53D6\u6D88", "\u8986\u76D6", "\u4FDD\u5B58"],
      defaultId: 0,
      title: "\u6587\u4EF6\u5DF2\u5B58\u5728",
      message: `\u6587\u4EF6 "${fileName}" \u5DF2\u5B58\u5728\uFF0C\u662F\u5426\u8981\u8986\u76D6\u5F53\u524D\u5185\u5BB9\uFF1F`,
      detail: '\u9009\u62E9"\u4FDD\u5B58"\u5C06\u5148\u4FDD\u5B58\u5F53\u524D\u5185\u5BB9\uFF0C\u7136\u540E\u6253\u5F00\u65B0\u6587\u4EF6\u3002'
    });
    return result.response;
  });
  import_electron.ipcMain.handle("file:resolveImagePath", async (_event, markdownFilePath, imagePath) => {
    if (!markdownFilePath || !imagePath) {
      return imagePath;
    }
    if (import_node_path.default.isAbsolute(imagePath)) {
      return imagePath;
    }
    const markdownDir = import_node_path.default.dirname(markdownFilePath);
    const absoluteImagePath = import_node_path.default.resolve(markdownDir, imagePath);
    if (fs.existsSync(absoluteImagePath)) {
      const fileUrl = `file://${absoluteImagePath.replace(/\\/g, "/")}`;
      return fileUrl;
    }
    return imagePath;
  });
  import_electron.ipcMain.handle("file:readByPath", async (_event, filePath) => {
    try {
      if (!filePath || !fs.existsSync(filePath))
        return null;
      const isMd = /\.(?:md|markdown)$/i.test(filePath);
      if (!isMd)
        return null;
      const content = fs.readFileSync(filePath, "utf-8");
      return { filePath, content };
    } catch (error) {
      console.error("Failed to read file:", error);
      return null;
    }
  });
}
function close(win2) {
  if (isQuitting) {
    return;
  }
  if (isSaved) {
    isQuitting = true;
    win2.close();
    import_electron.app.quit();
  } else {
    if (win2 && !win2.isDestroyed()) {
      win2.webContents.send("close:confirm");
    }
  }
}
function getIsQuitting() {
  return isQuitting;
}
var fs, import_node_path, import_electron, import_font_list, isSaved, isQuitting;
var init_ipcBridge = __esm({
  "src/main/ipcBridge.ts"() {
    "use strict";
    fs = __toESM(require("node:fs"));
    import_node_path = __toESM(require("node:path"));
    import_electron = require("electron");
    import_font_list = __toESM(require_font_list());
    init_index();
    isSaved = true;
    isQuitting = false;
  }
});

// src/main/menu.ts
function createMenu(win2) {
  const template = [
    {
      label: "\u6587\u4EF6",
      submenu: [
        {
          label: "\u6253\u5F00",
          accelerator: "CmdOrCtrl+O",
          click: () => {
            win2.webContents.send("menu-open");
          }
        },
        {
          label: "\u4FDD\u5B58",
          accelerator: "CmdOrCtrl+S",
          click: () => {
            win2.webContents.send("menu-save");
          }
        }
      ]
    },
    {
      label: "\u7F16\u8F91",
      submenu: [
        { label: "\u64A4\u9500", accelerator: "CmdOrCtrl+Z", role: "undo" },
        { label: "\u91CD\u505A", accelerator: "Shift+CmdOrCtrl+Z", role: "redo" },
        { label: "\u526A\u5207", accelerator: "CmdOrCtrl+X", role: "cut" },
        { label: "\u590D\u5236", accelerator: "CmdOrCtrl+C", role: "copy" },
        { label: "\u7C98\u8D34", accelerator: "CmdOrCtrl+V", role: "paste" },
        { label: "\u5168\u9009", accelerator: "CmdOrCtrl+A", role: "selectAll" }
      ]
    },
    {
      label: "\u89C6\u56FE",
      submenu: [
        { label: "\u5B9E\u9645\u5927\u5C0F", accelerator: "CmdOrCtrl+0", role: "resetZoom" },
        { label: "\u5168\u5C4F", accelerator: "F11", role: "togglefullscreen" },
        {
          label: "\u5207\u6362\u89C6\u56FE",
          accelerator: "CmdOrCtrl+/",
          click: () => {
            win2.webContents.send("view:toggleView");
          }
        }
      ]
    },
    {
      label: "\u7A97\u53E3",
      submenu: [
        { label: "\u6700\u5C0F\u5316", accelerator: "CmdOrCtrl+M", role: "minimize" },
        { label: "\u5173\u95ED", accelerator: "CmdOrCtrl+W", role: "close" }
      ]
    }
  ];
  if (process.platform === "darwin") {
    template.unshift({
      label: "milkup",
      submenu: [
        { label: "\u9690\u85CF milkup", accelerator: "Cmd+H", role: "hide" },
        { label: "\u9690\u85CF\u5176\u4ED6", accelerator: "Cmd+Alt+H", role: "hideOthers" },
        { type: "separator" },
        {
          label: "\u9000\u51FA milkup",
          accelerator: "Cmd+Q",
          click: () => {
            close(win2);
          }
        }
      ]
    });
  }
  const menu = import_electron2.Menu.buildFromTemplate(template);
  import_electron2.Menu.setApplicationMenu(menu);
}
var import_electron2;
var init_menu = __esm({
  "src/main/menu.ts"() {
    "use strict";
    import_electron2 = require("electron");
    init_ipcBridge();
  }
});

// src/main/index.ts
var index_exports = {};
__export(index_exports, {
  createThemeEditorWindow: () => createThemeEditorWindow
});
module.exports = __toCommonJS(index_exports);
async function createWindow() {
  win = new import_electron3.BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    frame: false,
    titleBarStyle: "hidden",
    // ✅ macOS 专属
    icon: path2.join(__dirname, "../assets/icons/milkup.ico"),
    webPreferences: {
      sandbox: false,
      preload: path2.resolve(__dirname, "../../dist-electron/preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false
      // 允许加载本地文件
    }
  });
  import_electron3.globalShortcut.register("CommandOrControl+Shift+I", () => {
    if (win)
      win.webContents.openDevTools();
  });
  const indexPath = path2.join(__dirname, "../../dist", "index.html");
  if (process.env.VITE_DEV_SERVER_URL) {
    await win.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    await win.loadFile(indexPath);
  }
  if (process.env.VITE_DEV_SERVER_URL) {
    win.webContents.openDevTools();
  }
}
async function createThemeEditorWindow() {
  if (themeEditorWindow && !themeEditorWindow.isDestroyed()) {
    console.log("\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3\u5DF2\u5B58\u5728\uFF0C\u805A\u7126\u7A97\u53E3");
    themeEditorWindow.focus();
    return themeEditorWindow;
  }
  console.log("\u521B\u5EFA\u65B0\u7684\u4E3B\u9898\u7F16\u8F91\u5668\u7A97\u53E3");
  themeEditorWindow = new import_electron3.BrowserWindow({
    width: 1e3,
    height: 700,
    minWidth: 800,
    minHeight: 600,
    parent: win,
    modal: false,
    frame: false,
    titleBarStyle: "hidden",
    icon: path2.join(__dirname, "../assets/icons/milkup.ico"),
    webPreferences: {
      sandbox: false,
      preload: path2.resolve(__dirname, "../../dist-electron/preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false
    }
  });
  if (process.env.VITE_DEV_SERVER_URL) {
    await themeEditorWindow.loadURL(`${process.env.VITE_DEV_SERVER_URL}/theme-editor.html`);
  } else {
    const themeEditorPath = path2.join(__dirname, "../../dist", "theme-editor.html");
    await themeEditorWindow.loadFile(themeEditorPath);
  }
  if (process.env.VITE_DEV_SERVER_URL) {
    themeEditorWindow.webContents.openDevTools();
  }
  themeEditorWindow.on("closed", () => {
    themeEditorWindow = null;
  });
  return themeEditorWindow;
}
function sendLaunchFileIfExists() {
  const fileArg = process.argv.find((arg) => arg.endsWith(".md") || arg.endsWith(".markdown"));
  if (fileArg) {
    const absolutePath = path2.resolve(fileArg);
    if (fs2.existsSync(absolutePath)) {
      const content = fs2.readFileSync(absolutePath, "utf-8");
      win.webContents.send("open-file-at-launch", {
        filePath: absolutePath,
        content
      });
    } else {
      console.warn("[main] \u6587\u4EF6\u4E0D\u5B58\u5728:", absolutePath);
    }
  }
}
var fs2, path2, import_electron3, win, themeEditorWindow;
var init_index = __esm({
  "src/main/index.ts"() {
    fs2 = __toESM(require("node:fs"));
    path2 = __toESM(require("node:path"));
    import_electron3 = require("electron");
    init_ipcBridge();
    init_menu();
    themeEditorWindow = null;
    import_electron3.app.whenReady().then(async () => {
      registerIpcHandleHandlers(win);
      await createWindow();
      createMenu(win);
      registerIpcOnHandlers(win);
      sendLaunchFileIfExists();
      win.on("close", (event) => {
        if (process.platform === "darwin" && !getIsQuitting()) {
          event.preventDefault();
          win.webContents.send("close");
        }
      });
    });
    import_electron3.app.on("before-quit", (event) => {
      if (process.platform === "darwin" && !getIsQuitting()) {
        event.preventDefault();
        close(win);
      }
    });
    import_electron3.app.on("window-all-closed", () => {
      if (process.platform !== "darwin") {
        import_electron3.app.quit();
      }
    });
    import_electron3.app.on("activate", () => {
      if (import_electron3.BrowserWindow.getAllWindows().length === 0) {
        createWindow();
      } else {
        if (win && !win.isVisible()) {
          win.show();
        }
        if (win) {
          win.focus();
        }
      }
    });
  }
});
init_index();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createThemeEditorWindow
});
